const qwer = (a) => {
    for (let i = 0; i < a.length; i++) {
        console.log(`Имя: ${a[i].name} | возраст: ${a[i].age}`);
    }
}

const a = [
    {name: 'Alexey', age: 20}, 
    {name: 'Egor', age: 22}
]

qwer(a)