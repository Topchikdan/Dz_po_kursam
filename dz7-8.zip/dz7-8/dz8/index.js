let more50 = []
let less50 = []

for (let i = 0; i < 100; i++) {
    let a = Math.floor(Math.random() * 100)

    if (a > 50) {
        more50.push(a)
    } else {
        less50.push(a)
    }
}

console.log('Числа больше 50: ' + more50)
console.log('Числа меньше или равно 50: ' + less50)