for (let i = 0; i < 10; i++) {
    let a = Math.floor(Math.random() * 100)

    console.log(a)
}